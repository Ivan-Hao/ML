python hw3.py [learning rate]

-> python hw3.py 0.01